<script>
  import { onMount } from 'svelte';

  let statusText = "Connecting to server...";
  let isConnected = false;
  let isDisconnected = false;   // true after disconnect/failed — shows exit screen
  let disconnectReason = "";    // reason text from server
  let uiVisible = true;
  let uiReady = false;          // set to true when alt:V sends ui:ready
  let debugMode = false;        // only true if .cfg has debug = true
  let showExitConfirm = false;  // true when alt:V emits 'exit' (e.g. Alt+F4)
  let isReconnecting = false;   // true when user clicks Reconnect
  
  let isConsoleOpen = false;
  let logs = [];
  let consoleInput = "";

  const colors = [
      '#1e1e1e', '#666666', '#bd3f39', '#df5853', '#55b87f', '#63cd91',
      '#3972c2', '#508ee3', '#e6e34d', '#f6f366', '#ae4cb6', '#c978d1',
      '#4ba6c9', '#59b6d7', '#C0C0C0', '#FFFFFF'
  ];

  let htmlBuffer = "";

  function formatBytes(bytes) {
      if (bytes === 0) return '0 B';
      const k = 1024;
      const sizes = ['B', 'KB', 'MB', 'GB'];
      const i = Math.floor(Math.log(bytes) / Math.log(k));
      return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  function confirmExit() {
      if (typeof alt !== 'undefined') {
          alt.emit('exit');
      } else {
          window.close();
      }
  }

  function cancelExit() {
      showExitConfirm = false;
      if (typeof alt !== 'undefined') {
          // Return focus to the game if we are playing and console is not open
          if (isConnected && !isConsoleOpen) {
              alt.emit('ui:open', false);
          }
      }
  }

  function executeCommand() {
      if (!consoleInput.trim()) return;
      if (typeof alt !== 'undefined') {
          alt.emit('console:execute', consoleInput);
      } else {
          logs = [...logs, "Command executed: " + consoleInput];
      }
      consoleInput = "";
  }

  onMount(async () => {
      // Check if debug mode is enabled in .cfg via proxy
      try {
          const res = await fetch('http://127.0.0.1:8080/cfg/debug');
          if (res.ok) {
              const data = await res.json();
              debugMode = data.debug === true;
          }
      } catch (e) {
          debugMode = false;
      }

      if (typeof alt !== 'undefined') {
          // alt:V signals the engine is ready — show UI
          alt.on('ui:ready', () => {
              uiReady = true;
              if (!isConnected) {
                  alt.emit('ui:open', true);
                  alt.emit('cursor', true); // Try standard events
                  if (typeof alt.showCursor === 'function') {
                      alt.showCursor(true);
                      alt.toggleGameControls(false);
                  }
              }
          });

          // alt:V controls UI visibility (hide in-game, show on exit)
          alt.on('ui:toggle', (state) => {
              uiVisible = typeof state === 'boolean' ? state : !uiVisible;
          });

          alt.on('connection:connecting', () => { statusText = "Connecting to server..."; isDisconnected = false; });
          alt.on('connection:joining', () => { statusText = "Joining game..."; });
          alt.on('connection:startingResources', () => { statusText = "Starting resources..."; });
          alt.on('connection:preloadingMods', () => { statusText = "Preloading mods..."; });
          alt.on('connection:reloadingGameMap', () => { statusText = "Reloading game map..."; });
          alt.on('connection:startingGame', () => { statusText = "Starting game..."; });
          alt.on('connection:downloadingResources', () => { statusText = "Downloading resources..."; });
          alt.on('connection:validatingResources', () => { statusText = "Validating resources..."; });
          alt.on('connection:downloadingRuntimes', () => { statusText = "Downloading runtimes..."; });
          alt.on('connection:inQueue', (msg) => { statusText = "In queue: " + (msg || ""); });

          alt.on('connection:disconnected', (msg) => {
              isConnected = false;
              isDisconnected = true;
              isReconnecting = false;
              disconnectReason = msg || "Connection lost";
              uiVisible = true;
              isConsoleOpen = false;
              alt.emit('ui:open', true);
          });

          alt.on('connection:failed', (msg) => {
              isConnected = false;
              isDisconnected = true;
              disconnectReason = msg || "Connection failed";
              uiVisible = true;
              isConsoleOpen = false;
          });

          alt.on('connection:connected', () => {
              isConnected = true;
              isDisconnected = false;
              disconnectReason = "";
              isConsoleOpen = false;
              alt.emit('ui:open', false);
          });

          alt.on('exit', () => {
              if (showExitConfirm) return;
              showExitConfirm = true;
              if (typeof alt !== 'undefined') {
                  alt.emit('ui:open', true);
              }
          });

          alt.on('console:push', (color, value) => {
              let safeValue = value.replace(/&/g, "&amp;")
                 .replace(/</g, "&lt;")
                 .replace(/>/g, "&gt;");
              let colorHex = colors[color] || '#C0C0C0';
              if (color !== 14) {
                  htmlBuffer += `<span style="color: ${colorHex}">${safeValue}</span>`;
              } else {
                  htmlBuffer += safeValue;
              }
          });

          alt.on('console:end', () => {
              if (htmlBuffer) {
                  logs = [...logs, htmlBuffer];
                  if (logs.length > 200) logs.shift();
                  htmlBuffer = "";
              }
              const output = document.querySelector('.console-output');
              if (output) {
                  setTimeout(() => output.scrollTop = output.scrollHeight, 10);
              }
          });

          alt.on('console:reset', () => {
              htmlBuffer = "";
          });

          alt.on('console:open', (state) => {
              isConsoleOpen = typeof state === 'boolean' ? state : !isConsoleOpen;
          });

          alt.on('console:clear', () => {
              logs = [];
          });
      } else {
          // In browser (non-alt:V) mode — show UI immediately
          uiReady = true;
          window.debugExit = () => { showExitConfirm = true; };
          window.debugDisconnect = (reason = "Connection lost") => {
              isConnected = false;
              isDisconnected = true;
              isReconnecting = false;
              disconnectReason = reason;
              uiVisible = true;
              showExitConfirm = false;
          };
      }

      const handleKeyDown = (e) => {
          if (showExitConfirm) {
              if (e.code === 'Enter' || e.key === 'Enter') {
                  e.preventDefault();
                  e.stopPropagation();
                  confirmExit();
              }
              if (e.code === 'Escape' || e.key === 'Escape') {
                  e.preventDefault();
                  e.stopPropagation();
                  cancelExit();
              }
              return;
          }

          if (uiReady && isDisconnected && uiVisible && !isConsoleOpen) {
              if (e.code === 'Enter' || e.key === 'Enter') {
                  e.preventDefault();
                  e.stopPropagation();
                  confirmExit();
              }
              if (e.code === 'KeyR' || e.key === 'r' || e.key === 'R' || e.key === 'к' || e.key === 'К') {
                  e.preventDefault();
                  e.stopPropagation();
                  if (!isReconnecting) {
                      isReconnecting = true;
                      if (typeof alt !== 'undefined') alt.emit('console:execute', 'reconnect');
                  }
              }
          }

          if (e.code === 'F8' || e.key === 'F8') {
              if (debugMode) {
                  e.preventDefault();
                  isConsoleOpen = !isConsoleOpen;
              }
          }
      };

      const handleGlobalMouseAndKeyUp = (e) => {
          if (showExitConfirm || (uiReady && isDisconnected && uiVisible) || (uiReady && !isConnected && uiVisible)) {
              if (e.type === 'keyup' && (e.code === 'Escape' || e.key === 'Escape' || e.code === 'Enter' || e.key === 'Enter')) {
                  e.preventDefault();
                  e.stopPropagation();
              }
          }
      };

      document.addEventListener('keydown', handleKeyDown, { capture: true });
      document.addEventListener('keyup', handleGlobalMouseAndKeyUp, { capture: true });

      return () => {
          document.removeEventListener('keydown', handleKeyDown, { capture: true });
          document.removeEventListener('keyup', handleGlobalMouseAndKeyUp, { capture: true });
      };
  });
</script>

<main>
  <!-- Loading overlay: shown until alt:V sends ui:ready -->
  <div class="gta-modal loading-overlay" class:ready={uiReady} on:mousedown|self={(e) => { e.preventDefault(); e.stopPropagation(); }}>
    <div class="gta-content">
      <h1 class="gta-title">CONNECTING</h1>
      <div class="gta-divider"></div>
    </div>
    <div class="loader loader--large"></div>
  </div>

  <!-- Disconnect / Failed screen -->
  {#if uiReady && isDisconnected && uiVisible}
  <div class="gta-modal" style={isConsoleOpen ? 'opacity: 0.2' : 'opacity: 1'} on:mousedown|self={(e) => { e.preventDefault(); e.stopPropagation(); }}>
    <div class="gta-content">
      <h1 class="gta-title">DISCONNECTED</h1>
      <div class="gta-divider"></div>
      <p class="gta-desc">{disconnectReason}</p>
      <div class="gta-divider"></div>
    </div>
    <div class="gta-actions">
        <!-- svelte-ignore a11y-click-events-have-key-events -->
        <!-- svelte-ignore a11y-no-static-element-interactions -->
          {#if !isReconnecting}
          <div class="gta-action" on:click={() => { 
              isReconnecting = true; 
              if (typeof alt !== 'undefined') alt.emit('console:execute', 'reconnect'); 
          }}>
              <kbd>R</kbd>
              <span>RECONNECT</span>
          </div>
          {:else}
          <div class="loader" style="position: static; margin-top: auto; margin-bottom: auto;"></div>
          {/if}
        <!-- svelte-ignore a11y-click-events-have-key-events -->
        <!-- svelte-ignore a11y-no-static-element-interactions -->
        <div class="gta-action" on:click={confirmExit}>
          <span>Exit</span>
          <kbd>Enter</kbd>
        </div>
    </div>
  </div>
  {/if}

  <!-- Connection progress screen: shown when ready, connecting, not yet in game -->
  {#if uiReady && !isConnected && !isDisconnected && uiVisible}
  <div class="gta-modal" style={isConsoleOpen ? 'opacity: 0.2' : 'opacity: 1'} on:mousedown|self={(e) => { e.preventDefault(); e.stopPropagation(); }}>
    <div class="gta-content">
      <h1 class="gta-title">CONNECTING</h1>
      <div class="gta-divider"></div>
      <h1 class="gta-desc" style="font-size: 32px; font-weight: 600;">{statusText}</h1>
      <div class="gta-divider"></div>
    </div>
    <div class="loader"></div>
  </div>
  {/if}

  <!-- Console (F8, debug mode only) -->
  {#if isConsoleOpen}
  <div class="console">
      <div class="console-output">
          {#each logs as logLine}
              <div class="log-line">{@html logLine}</div>
          {/each}
      </div>
      <div class="console-input-row">
          <span class="prompt">&gt;</span>
          <input
              type="text"
              bind:value={consoleInput}
              on:keydown={(e) => {
                  if (e.key === 'Enter') {
                      e.preventDefault();
                      executeCommand();
                  }
              }}
          />
      </div>
  </div>
  {/if}

  <!-- Exit Confirmation Modal (Alt+F4) -->
  {#if showExitConfirm}
  <div class="gta-modal" on:mousedown|self={(e) => { e.preventDefault(); e.stopPropagation(); }}>
    <div class="gta-content">
      <h1 class="gta-title">QUIT</h1>
      <div class="gta-divider"></div>
      <p class="gta-desc">Are you sure you want to quit Grand Theft Auto V? All unsaved data will be lost.</p>
      <div class="gta-divider"></div>
    </div>
    <div class="gta-actions">
      <!-- svelte-ignore a11y-click-events-have-key-events -->
      <!-- svelte-ignore a11y-no-static-element-interactions -->
      <div class="gta-action" on:click={cancelExit}>
        <span>No</span>
        <kbd>Esc</kbd>
      </div>
      <!-- svelte-ignore a11y-click-events-have-key-events -->
      <!-- svelte-ignore a11y-no-static-element-interactions -->
      <div class="gta-action" on:click={confirmExit}>
        <span>Yes</span>
        <kbd>Enter</kbd>
      </div>
    </div>
  </div>
  {/if}
</main>

<style>
  :global(html), :global(body) {
    transition: opacity 0.2s ease;
  }

  main {
    position: relative;
    width: 100%;
    height: 100%;
    pointer-events: none;
  }

  /* ── Loading overlay ── */
  .loading-overlay {
    z-index: 9998;
  }
  
  .loading-overlay.ready {
    opacity: 0;
    pointer-events: none;
  }

  .loader--large {
    width: 56px;
    height: 56px;
    border-width: 5px;
  }

  /* ── Shared Screen Styles (Connection & Disconnect) ── */
  .loader {
    position: absolute;
    bottom: 45px;
    right: 50px;
    width: 32px;
    height: 32px;
    border: 3px solid transparent;
    border-bottom-color: #ffffff;
    border-radius: 50%;
    animation: spin 1s linear infinite, fadeIn 0.6s ease;
    zoom: 0.8;
  }


  .reconnect-btn:active {
    background: rgba(85, 184, 127, 0.2);
  }

  /* ── Console ── */
  .console {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 50vh;
    background: rgba(20, 20, 20, 0.95);
    border-bottom: 2px solid #333;
    display: flex;
    flex-direction: column;
    font-family: 'Consolas', 'Courier New', monospace;
    z-index: 9999;
    pointer-events: auto;
  }

  .console-output {
    flex: 1;
    overflow-y: auto;
    padding: 10px;
    color: #C0C0C0;
    font-size: 14px;
    line-height: 1.4;
    word-wrap: break-word;
    white-space: pre-wrap;
  }

  .log-line {
      min-height: 20px;
  }

  .console-input-row {
    display: flex;
    align-items: center;
    background: rgba(0, 0, 0, 0.5);
    padding: 5px 10px;
    border-top: 1px solid #333;
  }

  .prompt {
    color: #63cd91;
    margin-right: 10px;
    font-weight: bold;
  }

  input {
    flex: 1;
    background: transparent;
    border: none;
    color: #fff;
    font-family: inherit;
    font-size: 14px;
    outline: none;
  }

  /* ── GTA V Exit Modal ── */
  .gta-modal {
    position: fixed;
    top: 0; left: 0;
    width: 100vw; height: 100vh;
    background: #000000 url('./assets/bg.png') no-repeat center center;
    background-size: cover;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    z-index: 10000;
    pointer-events: auto;
    animation: fadeIn 0.15s ease;
  }

  .gta-content {
    width: 80%;
    max-width: 900px;
    text-align: center;
    display: flex;
    flex-direction: column;
    align-items: center;
    zoom: 0.8;
  }

  .gta-title {
    font-family: 'Gilroy', 'Inter', sans-serif;
    color: #f3b72c;
    font-size: 80px;
    margin: 0 0 10px 0;
    text-transform: uppercase;
    letter-spacing: 2px;
    font-weight: 800;
  }

  .gta-divider {
    height: 2px;
    background: #ffffff;
    width: 100%;
    margin: 15px 0;
  }

  .gta-desc {
    color: #ffffff;
    font-family: 'Gilroy', 'Inter', sans-serif;
    font-size: 22px;
    margin: 0;
    line-height: 1.5;
    font-weight: 500;
  }

  .gta-actions {
    position: absolute;
    bottom: 40px;
    right: 50px;
    display: flex;
    gap: 30px;
    zoom: 0.8;
  }

  .gta-action {
    display: flex;
    align-items: center;
    gap: 8px;
    cursor: pointer;
    transition: opacity 0.2s;
  }

  .gta-action:hover {
    opacity: 0.7;
  }

  .gta-action span {
    color: #ffffff;
    font-family: 'Gilroy', 'Inter', sans-serif;
    font-size: 20px;
    font-weight: 600;
  }

  .gta-action kbd {
    background: #ffffff;
    color: #000000;
    font-family: 'Gilroy', 'Inter', sans-serif;
    font-weight: 700;
    font-size: 16px;
    padding: 6px 12px;
    border-radius: 3px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
  }

  /* ── Animations ── */
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }

  @keyframes pulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.15); }
    100% { transform: scale(1); }
  }

  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to   { opacity: 1; transform: translateY(0); }
  }
</style>
